"""Internal LLM implementation modules."""

