"""Backward-compatible import shim for the unified LLM worker runtime."""

from deva.llm_parts.worker_runtime import run_ai_in_worker, run_sync_in_worker, submit_ai_coro
